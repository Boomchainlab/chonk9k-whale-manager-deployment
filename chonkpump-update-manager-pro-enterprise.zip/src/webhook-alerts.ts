import axios from 'axios';

async function sendWebhookNotification(webhookUrl: string, message: string) {
    try {
        await axios.post(webhookUrl, { content: message });
        console.log('Webhook sent:', message);
    } catch (error) {
        console.error('Error sending webhook:', error);
    }
}

export { sendWebhookNotification };
