import { Connection, PublicKey, Keypair, Transaction, SystemProgram } from '@solana/web3.js';
import axios from 'axios';
import dotenv from 'dotenv';

dotenv.config();

const { RPC_URL, MINT_ADDRESS, NEW_UPDATE_AUTHORITY, WEBHOOK_URL, MAX_RETRIES } = process.env;

// Create Solana connection and keypair
const connection = new Connection(RPC_URL, 'confirmed');
const payerKeypair = Keypair.fromSecretKey(new Uint8Array(JSON.parse(fs.readFileSync(process.env.PAYER_KEYPAIR_PATH as string).toString())));

async function freezeThawToken(isFreeze: boolean) {
    try {
        const transaction = new Transaction().add(
            SystemProgram.transfer({
                fromPubkey: payerKeypair.publicKey,
                toPubkey: new PublicKey(MINT_ADDRESS),
                lamports: 0,
            })
        );

        // Send transaction
        const txHash = await connection.sendTransaction(transaction, [payerKeypair]);
        console.log(\`Transaction sent: \${txHash}\`);

        // Notify via webhook
        await sendWebhookNotification(isFreeze ? 'freeze' : 'thaw');

    } catch (error) {
        console.error('Error during freeze/thaw:', error);
    }
}

async function sendWebhookNotification(action: string) {
    try {
        await axios.post(WEBHOOK_URL, {
            content: `The token authority has been ${action}d! Action: ${action}, Token: ${MINT_ADDRESS}`,
        });
        console.log('Webhook notification sent.');
    } catch (error) {
        console.error('Error sending webhook:', error);
    }
}

const action = process.argv[2] || 'thaw'; // Default action is 'thaw'
const isFreeze = action === 'freeze';

freezeThawToken(isFreeze);
