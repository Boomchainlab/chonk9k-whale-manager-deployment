#!/bin/bash

echo "🚀 Setting up CHONKPUMP Update Manager..."

# Step 1: Install dependencies
echo "📦 Installing npm packages..."
npm install

# Step 2: Build the TypeScript project
echo "🔨 Building project..."
npm run build

# Step 3: Check .env file
if [ ! -f .env ]; then
  echo "⚠️  No .env file found! Please create one with your RPC URL, MINT_ADDRESS, and other configs."
  exit 1
fi

# Step 4: Provide usage instructions
echo "✅ Setup complete! Available Commands:"
echo ""
echo "Freeze Token Transfers:      npm run freeze"
echo "Thaw Token Transfers:         npm run thaw"
echo "Monitor Whale Wallets:        npm run monitor-whales"
echo ""
echo "You're now ready to execute strategic control operations on $CHONK9K!"
